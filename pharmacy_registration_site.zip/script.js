// Basic client-side validation
document.addEventListener('DOMContentLoaded', () => {
  // signup form
  const signupForm = document.getElementById('signupForm');
  if (signupForm) {
    const email = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirmPassword');
    const passwordError = document.getElementById('passwordError');

    function validateEmail(value){
      // ensure contains "@" and ends with ".com" (case-insensitive)
      if (!value.includes('@')) return {ok:false, msg:'الإيميل لازم يحتوي على علامة @'};
      if (!value.toLowerCase().endsWith('.com')) return {ok:false, msg:'الإيميل لازم ينتهي بـ .com'};
      // basic minimal structure check
      const simple = /^[^\\s@]+@[^\\s@]+\\.com$/i;
      if (!simple.test(value)) return {ok:false, msg:'الإيميل مش بصيغة صحيحة'};
      return {ok:true};
    }

    signupForm.addEventListener('submit', (e) => {
      e.preventDefault();
      emailError.textContent = '';
      passwordError.textContent = '';

      const emailVal = email.value.trim();
      const passVal = password.value;
      const confirmVal = confirmPassword.value;

      const emailValid = validateEmail(emailVal);
      if (!emailValid.ok) {
        emailError.textContent = emailValid.msg;
        email.focus();
        return;
      }

      if (passVal.length < 6) {
        passwordError.textContent = 'كلمة المرور لازم تبقى 6 أحرف أو أكثر';
        password.focus();
        return;
      }

      if (passVal !== confirmVal) {
        passwordError.textContent = 'كلمة المرور وتأكيدها مش متطابقين';
        confirmPassword.focus();
        return;
      }

      // If all good, show a success message (in real app you'd send to server)
      alert('تم التسجيل بنجاح — (هذه بيئة تجريبية، البيانات مش بتتخزن فعلياً)');
      signupForm.reset();
    });
  }

  // login form
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    const loginEmail = document.getElementById('loginEmail');
    const loginEmailError = document.getElementById('loginEmailError');

    function validateEmail(value){
      if (!value.includes('@')) return {ok:false, msg:'الإيميل لازم يحتوي على علامة @'};
      if (!value.toLowerCase().endsWith('.com')) return {ok:false, msg:'الإيميل لازم ينتهي بـ .com'};
      const simple = /^[^\\s@]+@[^\\s@]+\\.com$/i;
      if (!simple.test(value)) return {ok:false, msg:'الإيميل مش بصيغة صحيحة'};
      return {ok:true};
    }

    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      loginEmailError.textContent = '';
      const v = validateEmail(loginEmail.value.trim());
      if (!v.ok) {
        loginEmailError.textContent = v.msg;
        loginEmail.focus();
        return;
      }
      alert('نجحت محاولة الدخول (تجريبى)');
      loginForm.reset();
    });
  }
});
